<!-- Sikha Rani -->

function saveSelection(sel){
    /* This function is called when the user clicks a list item */
    /* The ID of the list item clicked will be saved in Local Storage */

// Check browser support of Local Storage
    if (typeof(Storage) !== "undefined") {
        // Store the selected item's ID in a key called "selected"
        localStorage.setItem("selected", sel);
        // Now Open the next page in the same window as this current page
        window.open('Page2.html', "_self");
    }
    else { // use cookies if local storage not defined

        checkCookie(sel);
        window.open('Page2.html', "_self");
    }

}
//set the value of recipe id selected by the user in a cookie for 30 days
function setCookie(cname, cvalue, exdays) {
    var expDate = new Date();
    expDate.setTime(expDate.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + expDate.toGMTString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}
//get the cookie value for cookie recipe id
function getCookie(cname) {

    var name = cname + "=";
    var ca = document.cookie.split(';');
    console.log(ca);
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1);
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
//check if cookie is set ,if not then set the cookie value
function checkCookie(sel) {
    var id = getCookie("selectedid");
    if (id!= "") {
        alert("Last time you had selected " + id+ " Starting a new search for "+ sel);
        id=sel;
        setCookie("selectedid", id, 30);


    }
    else {
        id=sel;
        if (id != "" && id != null) {
            setCookie("selectedid", id, 30);


        }
    }

}
